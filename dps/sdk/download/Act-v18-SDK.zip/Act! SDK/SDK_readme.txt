Read me - Act! Software Development Kit (SDK) 
Documentation 
(12/08/2015) The entire documentation set is organized into one Help file. Open the Docs folder and double-click Act! SDK.htm.

 The Help format is WebHelp to allow uploading to an intranet page.Visit http://community.act.com > Developer's Lounge for up-to-date white papers, developer blogs, and community forums.













